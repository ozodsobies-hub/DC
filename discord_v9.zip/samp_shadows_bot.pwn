// ShadowsRP Bot - SA-MP Pawn Script
// Fayl nomi: shadows_bot.pwn
// SA-MP server ga quyidagicha yuklanadi:
// filterscripts shadows_bot   (server.cfg da)
// Yoki: gamemode ga include qilib

#include <a_samp>
#include <a_mysql>

#define BOT_NAME    "Shadows_Bot"
#define BOT_ADM     10
#define AZ_X        373.0
#define AZ_Y        173.0
#define AZ_Z        1008.0
#define AZ_INT      11

// MySQL ulanish (server.cfg yoki mysql.ini da)
#define DB_HOST     "188.127.241.8"
#define DB_USER     "gs137892"
#define DB_PASS     "XFpWuN7kssXj"
#define DB_NAME     "gs137892"

new MySQL:g_DB;
new g_BotID = INVALID_PLAYER_ID;

forward OnBotSpawned();
forward CheckDCCommand();
forward DelayedKick(playerid);

public OnGameModeInit() {
    new MySQLOpt:opt = mysql_init_options();
    mysql_set_option(opt, AUTO_RECONNECT, true);
    g_DB = mysql_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, opt);
    if (mysql_errno(g_DB) != 0) {
        print("[BOT] MySQL ulanishda xato!");
    } else {
        print("[BOT] MySQL ulandi!");
    }
    SetTimer("CheckDCCommand", 3000, true);
    print("[BOT] Shadows_Bot yuklandi!");
    return 1;
}

public OnPlayerConnect(playerid) {
    new name[24];
    GetPlayerName(playerid, name, 24);
    if (!strcmp(name, BOT_NAME, false)) {
        g_BotID = playerid;
        print("[BOT] Shadows_Bot ulandi!");
        // Admin daraja berish
        new q[128];
        mysql_format(g_DB, q, 128, "UPDATE accounts SET admin=%d WHERE name='%e'", BOT_ADM, BOT_NAME);
        mysql_tquery(g_DB, q);
        SetTimerEx("OnBotSpawned", 1500, false, "");
    }
    return 1;
}

public OnBotSpawned() {
    if (g_BotID == INVALID_PLAYER_ID) return;
    SpawnPlayer(g_BotID);
    SetPlayerPos(g_BotID, AZ_X, AZ_Y, AZ_Z);
    SetPlayerInterior(g_BotID, AZ_INT);
    SetPlayerVirtualWorld(g_BotID, 0);
    SendPlayerMessageToAll(g_BotID, "Salom! Men Shadows_Bot. Admin zonada 24/7 turaman!");
    print("[BOT] Admin zone ga teleport qilindi!");
}

public CheckDCCommand() {
    if (g_BotID == INVALID_PLAYER_ID) return;
    mysql_tquery(g_DB, "SELECT setting_value FROM settings WHERE setting_key='dc_game_command' LIMIT 1", "OnDCCmdResult");
}

forward OnDCCmdResult();
public OnDCCmdResult() {
    new rows;
    cache_get_row_count(rows);
    if (!rows) return;
    new cmd[512];
    cache_get_value_name(0, "setting_value", cmd, 512);
    if (!strlen(cmd) || !strcmp(cmd, "none")) return;

    // Buyruqni bajar
    RunCommand(cmd);

    // Tozalash
    mysql_tquery(g_DB, "UPDATE settings SET setting_value='none' WHERE setting_key='dc_game_command'");
}

RunCommand(const cmd[]) {
    // Format: action:nick:value:reason
    new parts[4][128], i, pi, ci;
    for (i = 0; cmd[i] && ci < 4; i++) {
        if (cmd[i] == ':') { pi = 0; ci++; }
        else parts[ci][pi++] = cmd[i];
    }
    new action[32], nick[24], value[64], reason[128];
    strmid(action, parts[0], 0, 32);
    strmid(nick, parts[1], 0, 24);
    strmid(value, parts[2], 0, 64);
    strmid(reason, parts[3], 0, 128);

    new q[512];
    if (!strcmp(action, "ban")) {
        mysql_format(g_DB, q, 512, "INSERT INTO ban_list(player,admin,reason,date) VALUES('%e','%e','%e',NOW()) ON DUPLICATE KEY UPDATE reason='%e'", nick, BOT_NAME, reason, reason);
        mysql_tquery(g_DB, q);
        SendBotMsg("~r~[BOT] ~w~%s banland! Sabab: %s", nick, reason);
    }
    else if (!strcmp(action, "mute")) {
        mysql_format(g_DB, q, 512, "UPDATE accounts SET mute=%d WHERE name='%e'", strval(value), nick);
        mysql_tquery(g_DB, q);
        SendBotMsg("~y~[BOT] ~w~%s %s daqiqa mute oldi!", nick, value);
    }
    else if (!strcmp(action, "warn")) {
        mysql_format(g_DB, q, 512, "UPDATE accounts SET warn=warn+1 WHERE name='%e'", nick);
        mysql_tquery(g_DB, q);
        SendBotMsg("~y~[BOT] ~w~%s warn oldi! Sabab: %s", nick, reason);
    }
    else if (!strcmp(action, "jail")) {
        mysql_format(g_DB, q, 512, "UPDATE accounts SET jail=%d WHERE name='%e'", strval(value), nick);
        mysql_tquery(g_DB, q);
        SendBotMsg("~r~[BOT] ~w~%s %s daqiqa qamoqqa tushdi!", nick, value);
    }
    else if (!strcmp(action, "kick")) {
        new pid = FindPlayer(nick);
        if (pid != INVALID_PLAYER_ID) SetTimerEx("DelayedKick", 200, false, "i", pid);
        SendBotMsg("~r~[BOT] ~w~%s kicklandi! Sabab: %s", nick, reason);
    }
    else if (!strcmp(action, "pul")) {
        mysql_format(g_DB, q, 512, "UPDATE accounts SET money=money+%d WHERE name='%e'", strval(value), nick);
        mysql_tquery(g_DB, q);
        SendBotMsg("~g~[BOT] ~w~%s ga $%s berildi!", nick, value);
    }
    else if (!strcmp(action, "chat")) {
        SendBotMsg("[DC] %s", reason);
    }
    else if (!strcmp(action, "ann")) {
        GameTextForAll(reason, 5000, 4);
        SendClientMessageToAll(-1, reason);
    }
}

public DelayedKick(playerid) { Kick(playerid); }

SendBotMsg(const fmt[], {Float,_}:...) {
    new msg[256];
    format(msg, 256, fmt, ___(1));
    if (g_BotID != INVALID_PLAYER_ID) SendPlayerMessageToAll(g_BotID, msg);
}

FindPlayer(const name[]) {
    for (new i = 0; i < MAX_PLAYERS; i++) {
        if (!IsPlayerConnected(i)) continue;
        new n[24]; GetPlayerName(i, n, 24);
        if (!strcmp(n, name, false)) return i;
    }
    return INVALID_PLAYER_ID;
}

public OnPlayerDisconnect(playerid, reason) {
    if (playerid == g_BotID) { g_BotID = INVALID_PLAYER_ID; print("[BOT] Shadows_Bot chiqdi!"); }
    return 1;
}

public OnGameModeExit() { mysql_close(g_DB); return 1; }
